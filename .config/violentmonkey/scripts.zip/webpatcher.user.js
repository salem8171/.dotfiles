// ==UserScript==
// @name         webpatcher
// @version      0.1.0
// @downloadURL  http://localhost:3000/js/webpatcher-user.js
// @description  try to take over the world!
// @author       salem8171
// @match        https://**/*
// @require      http://localhost:3000/js/webpatcher-bootstrap.js
// @run-at       document-start
// @grant        none
// ==/UserScript==
